# Loopback et zones natives EL8

Le template canonique écoute sur `local_loopback` (`127.0.0.1`) et les adresses FRONT/BACK locales. `/etc/named.rfc1912.zones` est inclus au niveau global, sans vues. Le rôle vérifie ce fichier ainsi que `/var/named/named.localhost`, `named.loopback`, `named.empty`, sans les réécrire ni accepter des liens symboliques pour ces quatre fichiers.

Le fichier natif EL8 inspecté déclare `localhost.localdomain`, `localhost`, la zone inverse IPv6 de `::1`, `1.0.0.127.in-addr.arpa` et `0.in-addr.arpa`. Le template omet désormais `empty-zones-enable` et utilise le défaut natif activé de BIND ; aucune valeur `no` n’est ajoutée. Cette option est indépendante de la racine privée `empty-root.zone` et du chargement des zones localhost. L'écoute IPv6 est désactivée ; les données natives AAAA `::1` et PTR IPv6 restent consultables via IPv4. Le rôle ne modifie pas `/etc/resolv.conf`.

La récursion locale permet les suffixes forwardés ; les autres noms suivent la racine privée NXDOMAIN, sauf les zones natives et autoritatives plus spécifiques. Les zones natives sont visibles à toutes les sources admises par `allow-query`, selon le modèle global sans vues. Les fichiers de données officiels ne sont pas personnalisés.

## Retrait de la déclaration explicite

Seule la ligne `empty-zones-enable yes;` est retirée de [named.conf.j2](../roles/bind9/templates/named.conf.j2), ainsi que des rendus [primaire](../examples/deux-zones-forwardees/named.conf) et [secondaire](../examples/deux-zones-forwardees/named-secondary.conf). Le défaut natif reste actif ; aucune désactivation globale n’est introduite et DNSSEC conserve son défaut `auto`. Les tests [test_native_loopback.py](../tests/test_native_loopback.py) et [integration_loopback.py](../tests/integration_loopback.py), ce document et le README sont alignés. Les autres fichiers de production restent identiques à la livraison source ; la liste exacte figure dans `DELIVERY.json`.

Le test DNS vérifie en UDP et TCP une réponse NXDOMAIN autoritative pour `250.255.255.10.in-addr.arpa`, avec une SOA de `10.in-addr.arpa` : il distingue ainsi la zone vide automatique d’une réponse de la racine privée. Les comparaisons de noms DNS ignorent la casse. Les sources BIND et leur comportement natif sont décrits dans la [documentation ISC](https://kb.isc.org/docs/aa-00800).

Pour revenir à une déclaration explicite, rétablir la ligne `empty-zones-enable yes;` et appliquer la configuration après contrôle BIND ; cette valeur exprime le même comportement. Ne pas la remplacer par `no`, qui désactiverait les zones automatiques.

```bash
sudo named-checkconf -z /etc/named.conf
dig -4 -b 127.0.0.1 @127.0.0.1 localhost A +norecurse
dig -4 -b 127.0.0.1 @127.0.0.1 localhost A +tcp +norecurse
dig -4 -b 127.0.0.1 @127.0.0.1 1.0.0.127.in-addr.arpa PTR +norecurse
dig -4 -b 127.0.0.1 @127.0.0.1 1.0.0.127.in-addr.arpa PTR +tcp +norecurse
dig -4 -b 127.0.0.1 @127.0.0.1 localhost AAAA +norecurse
```

Attendu : NOERROR, AA, A `127.0.0.1`, PTR `localhost.` et AAAA `::1`. Le rôle contrôle automatiquement les quatre premières réponses locales, les SOA exacts des zones métier et les SOA forwardés en UDP/TCP. Le moniteur facultatif contrôle le loopback et la présence de SOA autoritatifs, sans comparaison des serials ni interrogation des zones forwardées ; demander `bind_monitoring_enabled: true` et le tag `monitor` pour son timer systemd.

**EXÉCUTÉ** : laboratoire BIND EL8 9.11.36 et BIND 9.18.24, chacun 109 configurations et 284 contrôles DNS, avec fichiers natifs inchangés. Les vraies tâches Ansible loopback, disponibilité primaire et vérification des fichiers sont aussi exercées ; voir [CORRECTION_CONTROLES_DNS.md](CORRECTION_CONTROLES_DNS.md) pour le défaut d’échappement Jinja corrigé et les parties impactées. **NON EXÉCUTÉ** : recette sur votre système RHEL réel ; raisons, procédure et risques dans [VALIDATION_RHEL8.md](VALIDATION_RHEL8.md). Les modes DNSSEC `false`/`true`/`auto`, le canal RNDC uniquement IPv4 et les exceptions privées optionnelles sont décrits dans [DNSSEC.md](DNSSEC.md).

**EXÉCUTÉ sur cette révision :** 48 tests ciblés réussis avec chacun des moteurs Ansible 2.9.27/Jinja 2.10.3 et Jinja 3.0.3 ; contrôle syntaxique de l’inventaire de production, Pyflakes et compilation du test DNS. Le contrôle natif de la zone vide automatique réussit dans les deux moteurs BIND. Les suites complètes et workflows de la livraison précédente restent des preuves héritées, distinguées dans `DELIVERY.json`.
